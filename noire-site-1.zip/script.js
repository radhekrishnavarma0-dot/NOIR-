const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
try{const fl=document.createElement('link');fl.rel='stylesheet';fl.href='https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Inter:wght@400;500&display=swap';document.head.appendChild(fl)}catch(e){}
const IMG={"000": "images/000.jpg", "001": "images/001.jpg", "002": "images/002.jpg", "003": "images/003.jpg", "004": "images/004.jpg", "005": "images/005.jpg", "006": "images/006.jpg", "007": "images/007.jpg", "008": "images/008.jpg", "009": "images/009.jpg", "010": "images/010.jpg", "011": "images/011.jpg", "012": "images/012.jpg", "013": "images/013.jpg"};
const R=n=>'₹'+n.toLocaleString('en-IN');
const P=[
{id:1,n:'OUD NOIR',c:'Woody & Intense',p:4999,m:6499,no:['Oud','Saffron','Smoked Amber'],d:'Deep, mysterious, and unforgettable.',i:'001',col:'dark',tag:'Bestseller'},
{id:2,n:'ROSE VEIL',c:'Floral & Elegant',p:3499,m:4499,no:['Rose','Peony','White Musk'],d:'A delicate floral signature with timeless elegance.',i:'002',col:'floral',tag:'Bestseller'},
{id:3,n:'AMBER DUSK',c:'Warm & Sensual',p:4299,m:5499,no:['Amber','Vanilla','Sandalwood'],d:'Warm golden notes wrapped in a captivating finish.',i:'006',col:'dark'},
{id:4,n:'BLANC MUSC',c:'Fresh & Refined',p:3799,m:4899,no:['Bergamot','White Musk','Cedarwood'],d:'Clean, understated, and effortlessly sophisticated.',i:'013',col:'fresh',tag:'New'},
{id:5,n:'VELVET OUD',c:'Rich & Woody',p:5499,m:6999,no:['Black Pepper','Oud','Tonka Bean'],d:'Dark spice over a rich, smoky heart.',i:'007',col:'dark'},
{id:6,n:'GOLDEN HOUR',c:'Fresh & Warm',p:3999,m:5199,no:['Mandarin','Neroli','Golden Amber'],d:'Bright citrus melting into golden warmth.',i:'004',col:'fresh'},
{id:7,n:'MIDNIGHT BLOOM',c:'Floral & Woody',p:4599,m:5999,no:['Jasmine','Dark Rose','Patchouli'],d:'Dark florals with a velvet, earthy trail.',i:'000',col:'floral',tag:'New'},
{id:8,n:'SILK SKIN',c:'Soft & Musky',p:2999,m:3999,no:['Pear','Powdery Musk','Cashmere Woods'],d:'Soft, powdery, and close to the skin.',i:'011',col:'floral'}];
const pr=id=>P.find(x=>x.id==id),off=p=>Math.round((1-p.p/p.m)*100);
$$('[data-i]').forEach(e=>e.src=IMG[e.dataset.i]);
addEventListener('error',e=>{if(e.target.tagName=='IMG'){e.target.style.opacity=0;e.target.parentElement.classList.add('fb')}},true);
/* toast */
let tt;const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('o');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('o'),2400)};
/* grid */
let F='all',Q='';
const card=p=>`<article class="card"><div class="ph"><img src="${IMG[p.i]}" alt="NOIRÉ ${p.n} perfume, ${p.c}" loading="lazy">${p.tag?`<span class="tg">${p.tag}</span>`:''}<button class="qvb" data-act="qv" data-v="${p.id}" aria-label="Quick view ${p.n}">Quick View</button></div><div class="cb"><p class="lab">${p.c}</p><h3><small>NOIRÉ NO. 0${p.id}</small>${p.n}</h3><p class="ds">${p.d}</p><p class="nt">${p.no.join(' / ')}</p><p class="pc"><b>${R(p.p)}</b><s>${R(p.m)}</s><em>${off(p)}% off</em></p><button class="btn f" data-act="add" data-v="${p.id}">Add to Bag</button></div></article>`;
function grid(){const l=P.filter(p=>(F=='all'||p.col==F)&&(!Q||(p.n+p.c+p.no.join()).toLowerCase().includes(Q)));
$('#grid').innerHTML=l.length?l.map(card).join(''):'<p class="emp">No fragrances match your search. Try another note.</p>';
$$('.fl button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.v==F))}
/* cart (saved only in this browser) */
let C={};try{const s=JSON.parse(localStorage.getItem('noire_bag')||'{}');for(const k in s)if(pr(k)&&s[k]>0)C[k]=Math.min(10,s[k]|0)}catch(e){}
function upd(){try{localStorage.setItem('noire_bag',JSON.stringify(C))}catch(e){}
const n=Object.values(C).reduce((a,b)=>a+b,0);$('#cnt').textContent=n;$('#cnt').hidden=!n;
const ids=Object.keys(C),sub=ids.reduce((a,k)=>a+pr(k).p*C[k],0);
$('#ci').innerHTML=ids.length?ids.map(k=>{const p=pr(k);return`<div class="ci"><img src="${IMG[p.i]}" alt="${p.n}"><div><h4>${p.n}</h4><small style="color:var(--t)">${R(p.p)}</small><div class="r"><div class="qy"><button data-act="dec" data-v="${k}" aria-label="Decrease quantity of ${p.n}">−</button><output>${C[k]}</output><button data-act="inc" data-v="${k}" aria-label="Increase quantity of ${p.n}">+</button></div><button class="rm" data-act="rm" data-v="${k}">Remove</button></div></div></div>`}).join(''):'<p style="color:var(--t);padding:30px 0">Your bag is empty. Choose a fragrance to begin.</p>';
$('#df').innerHTML=(ids.length?`<div class="t"><span>Subtotal</span><b>${R(sub)}</b></div><button class="btn f" data-act="co">Checkout (demo)</button>`:'')+`<button class="btn" data-act="close">Continue Shopping</button><small>Demo prices. Your bag is saved only in this browser (localStorage) and never sent anywhere.</small>`}
const add=(id,q=1)=>{C[id]=Math.min(10,(C[id]||0)+q);upd();toast(pr(id).n+' added to bag')};
let last;const openCart=()=>{last=document.activeElement;$('#dr').classList.add('o');$('#ov').classList.add('o');$('#dr .x').focus()};
const closeCart=()=>{$('#dr').classList.remove('o');$('#ov').classList.remove('o');last&&last.focus&&last.focus()};
/* quick view */
let qty=1;
function qv(id){const p=pr(id);qty=1;$('#qv').innerHTML=`<button class="x" data-act="close" aria-label="Close quick view">×</button><div class="qg"><img src="${IMG[p.i]}" alt="NOIRÉ ${p.n} perfume"><div class="qi"><p class="lab">${p.c}</p><h2>${p.n}</h2><div class="chips">${p.no.map(n=>`<span>${n}</span>`).join('')}</div><p style="color:var(--t)">${p.d}</p><p class="pc"><b>${R(p.p)}</b><s>${R(p.m)}</s><em>${off(p)}% off</em></p><small style="color:var(--t)">Demo price, illustrative only.</small><div class="qy"><button data-act="qm" aria-label="Decrease quantity">−</button><output id="qn">1</output><button data-act="qp" aria-label="Increase quantity">+</button></div><button class="btn f" data-act="qadd" data-v="${id}">Add to Bag</button></div></div>`;$('#qv').showModal()}
/* policies */
const POL={privacy:['Privacy Policy',['NOIRÉ is a fictional demo store built by Houseofpri. It is not a real business and does not sell anything.','<b>What we collect:</b> nothing is sent to a server. An email typed into the newsletter form is checked in your browser and then discarded.','<b>Local storage:</b> your bag is saved in your browser (key noire_bag) so it survives a refresh. It stays on your device; clear your site data to remove it.','<b>Cookies and tracking:</b> this page sets no cookies and runs no analytics or ads. Fonts load from Google Fonts, which may see your IP address and browser details in the normal way.','Please do not enter real personal information into this demo.']],
terms:['Terms & Conditions',['<b>Demo only.</b> Products, prices, MRP, discounts, and testimonials are fictional. Nothing can be bought; no orders are placed and no payment is taken.','<b>Imagery.</b> Photographs are portfolio placeholders. Some show third-party brand names, used only to demonstrate design and not as endorsement. Replace them before any real launch.','<b>No warranty.</b> The site is provided as is, without promises of accuracy or availability.','<b>Ownership.</b> Third-party names and trademarks belong to their owners. NOIRÉ is an invented name.']],
security:['Security',['<b>No payments.</b> Checkout is disabled. The page never asks for card, bank, or ID details.','<b>No accounts.</b> There is no login and no password.','<b>Safe input.</b> Search and email input are used locally and are never run as code.','<b>Local only.</b> The bag is stored in your browser and can be cleared at any time. The page loads no third-party scripts, only a font stylesheet.','<b>Before a real launch:</b> use HTTPS, validate on the server, use a certified payment provider, and have a lawyer review the legal pages.']]};
function pol(k){const d=$('#pol');d.innerHTML=`<button class="x" data-act="close" aria-label="Close">×</button><div class="pb"><div class="tabs">${Object.keys(POL).map(t=>`<button data-act="pol" data-v="${t}" aria-pressed="${t==k}">${POL[t][0]}</button>`).join('')}</div><h2>${POL[k][0]}</h2>${POL[k][1].map(x=>`<p>${x}</p>`).join('')}<small style="color:var(--t)">Last updated 11 October 2026. Demo text, not legal advice.</small></div>`;if(!d.open)d.showModal()}
/* events */
const go=id=>$(id).scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'});
document.addEventListener('click',e=>{
const d=e.target.closest('dialog');if(d&&e.target===d){d.close();return}
const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act,v=b.dataset.v;
if(a=='add')add(+v);
else if(a=='qv')qv(+v);
else if(a=='qm'){qty=Math.max(1,qty-1);$('#qn').textContent=qty}
else if(a=='qp'){qty=Math.min(10,qty+1);$('#qn').textContent=qty}
else if(a=='qadd'){add(+v,qty);$('#qv').close();openCart()}
else if(a=='filt'){F=v;grid()}
else if(a=='col'){F=v;grid();go('#shop')}
else if(a=='inc'){C[v]=Math.min(10,C[v]+1);upd()}
else if(a=='dec'){C[v]=Math.max(1,C[v]-1);upd()}
else if(a=='rm'){delete C[v];upd()}
else if(a=='cart')openCart();
else if(a=='close'){const dl=b.closest('dialog');dl?dl.close():closeCart()}
else if(a=='co'){const ids=Object.keys(C);$('#co').innerHTML=`<button class="x" data-act="close" aria-label="Close">×</button><div class="pb"><p class="lab">Checkout</p><h2>Checkout is not enabled</h2><p>This is a portfolio demo. No payment is taken, no order is placed, and no personal details are collected.</p><ul>${ids.map(k=>`<li>${pr(k).n} × ${C[k]}</li>`).join('')}</ul><p><b>Demo total: ${R(ids.reduce((s,k)=>s+pr(k).p*C[k],0))}</b></p><button class="btn f" data-act="back">Back to Bag</button></div>`;$('#co').showModal()}
else if(a=='back'){$('#co').close()}
else if(a=='pol')pol(v);
else if(a=='ig')toast('Placeholder only. NOIRÉ has no real social account.');
else if(a=='mood'){const p=pr(v);$$('.md button').forEach(x=>x.setAttribute('aria-pressed',x==b));$('#rs').innerHTML=`<div class="rc"><img src="${IMG[p.i]}" alt="NOIRÉ ${p.n}"><div><p class="lab">Your match</p><h3>${p.n}</h3><p class="nt">${p.no.join(' / ')}</p><p style="color:var(--t)">${p.d}</p><p class="pc"><b>${R(p.p)}</b><s>${R(p.m)}</s><em>Demo price</em></p><button class="btn f" data-act="add" data-v="${p.id}">Add to Bag</button></div></div>`}
});
$('#sm').onclick=()=>{const m=$('#more'),o=m.hidden;m.hidden=!o;$('#sm').setAttribute('aria-expanded',o)};
$('#burger').onclick=()=>{const o=$('#menu').classList.toggle('o');$('#burger').setAttribute('aria-expanded',o)};
$('#menu').onclick=e=>{if(e.target.tagName=='A'){$('#menu').classList.remove('o');$('#burger').setAttribute('aria-expanded',false)}};
$('#srch').onclick=()=>{const o=$('#sf').classList.toggle('o');$('#srch').setAttribute('aria-expanded',o);if(o)$('#q').focus();else{Q='';$('#q').value='';grid()}};
$('#sf').onsubmit=e=>e.preventDefault();
$('#q').oninput=e=>{Q=e.target.value.trim().toLowerCase();F='all';grid();if(Q)go('#shop')};
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&$('#dr').classList.contains('o'))closeCart()});
$('#nf').onsubmit=e=>{e.preventDefault();const s=$('#ns');
if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test($('#em').value.trim())){s.textContent='Enter a valid email address.';s.className='er';$('#em').focus();return}
if(!$('#cb').checked){s.textContent='Please tick the consent box to continue.';s.className='er';return}
s.textContent='Demo only. Thank you. Your email was checked in your browser and was not stored or sent anywhere.';s.className='ok';e.target.reset()};
const sc=()=>$('#nav').classList.toggle('s',scrollY>40);addEventListener('scroll',sc,{passive:true});sc();
if('IntersectionObserver'in window){const io=new IntersectionObserver(l=>l.forEach(x=>{if(x.isIntersecting){x.target.classList.add('v');io.unobserve(x.target)}}),{threshold:.15});$$('.rv').forEach(x=>io.observe(x))}else $$('.rv').forEach(x=>x.classList.add('v'));
grid();upd();
setTimeout(()=>$$('.rv').forEach(x=>x.classList.add('v')),3000);